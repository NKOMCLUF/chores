"use client"

import  from "../script"

export default function SyntheticV0PageForDeployment() {
  return < />
}